Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/autocomplete-textbox-using-jquery-php-mysql/

============ Instruction ============
1. Create a database like "codexworld".

2. Import the skills.sql file into the database.

3. Open the search.php file and modify the $dbHost, $dbUsername, $dbPassword and $dbName variable value with your phpMyAdmin details.

4. Run the index.php file and test the functionality.


============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/autocomplete-textbox-using-jquery-php-mysql/#respond. We will reply your query ASAP.